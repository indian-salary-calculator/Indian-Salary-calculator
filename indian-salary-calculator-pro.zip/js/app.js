
const $=id=>document.getElementById(id);
const n=id=>Math.max(0,Number($(id)?.value)||0);
const money=x=>'₹'+Math.round(x).toLocaleString('en-IN');
function taxNew(income){let t=0,prev=0,bands=[[400000,0],[400000,.05],[400000,.10],[400000,.15],[400000,.20],[400000,.25],[Infinity,.30]];for(const [cap,r] of bands){const p=Math.max(0,Math.min(income,prev+cap)-prev);t+=p*r;prev+=cap;if(income<=prev)break}return t}
function taxOld(income){let t=0;if(income<=250000)return 0;let p=income-250000;t+=Math.min(p,250000)*.05;if(p>250000)t+=Math.min(p-250000,500000)*.20;if(p>750000)t+=(p-750000)*.30;return t}
function salaryCalc(){
 let gross=n('basic')+n('hra')+n('allow')+n('bonus'), pf=n('pf'),pt=n('pt'),other=n('other');
 let regime=$('regime').value,std=regime==='new'?75000:50000,taxable=Math.max(0,gross*12-std);
 let tax=(regime==='new'?taxNew(taxable):taxOld(taxable))*1.04;
 if(regime==='new'&&taxable<=1200000)tax=0;
 let monthlyTax=tax/12,net=Math.max(0,gross-pf-pt-other-monthlyTax);
 $('gross').textContent=money(gross);$('tax').textContent=money(monthlyTax);$('ded').textContent=money(pf+pt+other);$('net').textContent=money(net);$('annual').textContent=money(net*12);$('ctc').textContent=money(gross*12);
}
function simpleCalc(inputs,out,formula){const vals=inputs.map(id=>n(id));$(out).textContent=money(formula(...vals))}
